from flask import Flask, request, redirect, session, render_template
app= Flask(__name__)
app.secret_key= 'secret'

@app.route('/')
def main():

    session['gold']=0
    gold_count=session['gold']
    score='nothing'

    print session['gold']

    return render_template('index.html', gold_count=gold_count)



@app.route('/process_money', methods=['POST'])
def process_money():
    import random   
    import datetime

    loc=request.form['building'] #location
    win_lose= random.randint(0,1)
    print 'win or lose', win_lose
    print loc

    if loc == 'farm' and win_lose==1:
        rand=random.randint(10,20)
        session['gold']+=rand
        score='win'
    elif loc == 'farm' and win_lose==0:
        rand=random.randint(10,20)
        session['gold']-=rand
        score='lose'

    if loc == 'cave' and win_lose==1:
        rand=random.randint(5,10)
        session['gold']+=rand
        score='win'
    elif loc == 'cave' and win_lose==0:
        rand=random.randint(5,10)
        session['gold']-=rand
        score='lose'

    if loc == 'house' and win_lose==1:
        rand=random.randint(2,5)
        session['gold']+=rand
        score='win'
    elif loc == 'house' and win_lose==0:
        rand=random.randint(2,5)
        session['gold']-=rand
        score='lose'

    if loc == 'casino' and win_lose==1:
        rand=random.randint(0,50)
        session['gold']+=rand
        score='win'
    elif loc == 'casino' and win_lose==0:
        rand=random.randint(0,50)
        session['gold']-=rand
        score='lose'

    time= datetime.datetime.now().time()
    gold_count=session['gold']
    print gold_count
    print rand,'gold hit'
    print session['gold'],'gold total count'



    return render_template('index.html',score=score, loc=loc, gold_count=gold_count, rand=rand, time=time) 




















# @app.route('/',methods=['POST'])
# def house():
#     return render_template('index.html')


# @app.route('/',methods=['POST'])
# def cave():
#     return render_template('index.html')


# @app.route('/',methods=['POST'])
# def casino():
#     return render_template('index.html')


# @app.route('/',methods=['POST'])
# def farm():
#     return render_template('index.html')

app.run(debug=True)